module.exports = {
  HOST: "localhost",
  USER: "root",
  PASSWORD: "1234",
  DB: "SOIL_DATABASE_1",
  DIALECT: 'mysql',
};
